from CommonFunctionsMatrix import BSQHPriceMat3
from commonFunctions import interestRate_from_pcp
from py_vollib.black_scholes.implied_volatility import implied_volatility as iv
import matplotlib.pyplot as plt
from py_lets_be_rational.exceptions import BelowIntrinsicException, AboveMaximumException
import numpy as np
import csv
from scipy import optimize
from tabulate import tabulate
import time
import os

"Plotten van BSQH"

q = 0

def diffMarketAndBSQH_Mat(info, activationAt0, vecK, S0, N, L, imp_vols_market, vecT, vecr, q, flag):
    [volatility, clustRate, expRate, baseInt, mu_Y, sigma_Y] = info
    
    prices = BSQHPriceMat3(info, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    
    differences = []
    imp_vols = []    
    for i in range(len(vecK)): 
        imp_vols.append([])
        for j in range(len(vecT)):
            try:
                imp_vol_BSQH = iv(prices[i][j], S0, vecK[i], vecT[j], vecr[j], flag)
            except BelowIntrinsicException:
                imp_vol_BSQH = 0
            except AboveMaximumException:
                imp_vol_BSQH = 10
            imp_vols[i].append(imp_vol_BSQH)
            differences.append(np.abs(imp_vol_BSQH-imp_vols_market[i][j]))
      
    return sum(differences)

def optimimize_diff_in_IV_mat(vecK,S0, N,L,Vmarket, vecT, vecr, flag):
    Q0 = 0
    
    min_difference = float('inf')
    min_result = None
    
    imp_vols_market = []
    for i in range(len(vecK)):   
        imp_vols_market.append([])
        for j in range(len(vecT)):
            try:
                imp_vol_Vmarket = iv(Vmarket[i][j], S0, vecK[i], vecT[j], vecr[j], flag)
            except BelowIntrinsicException:
                imp_vol_Vmarket = 0 
            except AboveMaximumException:
                imp_vol_Vmarket = 10
            imp_vols_market[i].append(imp_vol_Vmarket)

    for i in range(10):
        IG_sigma = np.random.uniform(0.0,0.5)  # initial guess for volatility
        IG_alfa = np.random.uniform(0.001,10.0)
        IG_beta = np.random.uniform(IG_alfa,20.0)
        IG_lambdaS = np.random.uniform(0.0,10.0)
        IG_mu_Y = np.random.uniform(-5.0,5.0)
        IG_sigma_Y = np.random.uniform(0.0,5.0)
                
        initial_guesses = [IG_sigma, IG_alfa , IG_beta, IG_lambdaS, IG_mu_Y, IG_sigma_Y]
        
        bounds_sigma = (1e-5,10)
        bounds_alfa = (1e-5,10)
        bounds_beta = (1e-5,10)
        bounds_lambdaS = (1e-5,10)
        bounds_mu_Y = (-10,10)
        bounds_sigma_Y = (1e-5,10)
        
        
        Bounds = [bounds_sigma, bounds_alfa, bounds_beta, bounds_lambdaS, bounds_mu_Y, bounds_sigma_Y]
        
        start = time.time()
        result = optimize.minimize(diffMarketAndBSQH_Mat, initial_guesses, args=(Q0, vecK, S0, N, L, imp_vols_market, vecT, vecr, q, flag), bounds=Bounds)
        end = time.time()
        
        print((end - start)/60)
        difference = diffMarketAndBSQH_Mat(result.x, 0, vecK, S0, N, L, imp_vols_market, vecT, vecr,q, flag)

        if difference < min_difference:
            min_difference = difference
            min_result = result.x
    
    return list(min_result) + [imp_vols_market]

def getData(file):
    filepath = 'Data/' + file
    with open(filepath, 'r') as file:
        csv_reader = csv.reader(file)
        next(csv_reader)
        rows = list(csv_reader)
        maturity_values = np.array(rows[0], dtype = float)
        strike_values = np.array([row[0] for row in rows[1:]], dtype=float)
        call_matrix = np.array([row[1::2] for row in rows[1:]], dtype=float)
        put_matrix = np.array([row[2::2] for row in rows[1:]], dtype=float)

    return [maturity_values, strike_values, call_matrix, put_matrix]

def calculateIVBSQH(activationAt0, vecK, S0, N, L, vecT, vecr, q, Vmarket, stock):

    OptimizedSet = optimimize_diff_in_IV_mat(vecK, S0, N, L, Vmarket, vecT, vecr,"p")
    imp_vols_market = OptimizedSet[6]    

    putPrice = BSQHPriceMat3(OptimizedSet[:6], activationAt0, vecK, S0, N, L, vecT, vecr, q, "p")

    imp_vols_opt = []
    for i in range(len(vecK)):   
        imp_vols_opt.append([])
        for j in range(len(vecT)):
            try: 
                impVol = iv(putPrice[i][j], S0, vecK[i], vecT[j], vecr[j], "p")
            except BelowIntrinsicException:
                impVol = 0 
            except AboveMaximumException:
                impVol = 10
            imp_vols_opt[i].append(impVol)
    
    return [np.array(imp_vols_market), np.array(imp_vols_opt)]

def plotIVBSQH(activationAt0, vecK, S0, N, L, vecT, vecr, q, Vmarket, stock,figure_number):
    
    [imp_vols_market, imp_vols_opt] = calculateIVBSQH(activationAt0, vecK, S0, N, L, vecT, vecr, q, Vmarket,stock)
    print(imp_vols_market)
    print(imp_vols_opt)
    '''
    The calculateIV gives two matrices of implied volatilities. 
    It is a list of K lists with T values
    
    ''' 
    plt.figure(figure_number, (15, 10))
    for i in range(len(imp_vols_market.T)):
        plt.plot(vecK, imp_vols_market.T[i], label = "market iv for T={} days".format(str(vecT[i] * 365)))
        plt.scatter(vecK, imp_vols_opt.T[i], label = "model iv for T={} days".format(str(vecT[i] * 365)))
    
    save_path = 'Plots/IV/'
    filename = os.path.splitext(stock)[0] 
    picture = filename + "IV.png"
    
    
    plt.xlabel('Strike Price')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison For Stock {}'.format(filename))
    
    plt.legend()
    plt.grid(True)
    plt.savefig(save_path + picture)
    plt.show()
    
def calculateInterestRate(vecK, vecT, call_matrix, put_matrix, S0):

    interestRates = np.zeros(len(vecT))
    for j in range(len(vecT)):  
        IRperMaturity = []
        for i in range(len(vecK)):
            IRperMaturity.append(interestRate_from_pcp(call_matrix[i][j], put_matrix[i][j], S0, vecK[i],vecT[j]))
        interestRates[j] = sum(IRperMaturity)/len(vecK)
        
    return interestRates
    
def plotStock(N,L,S0,stock,figure_number):
    [maturity_values, strike_values, call_matrix, put_matrix]  = getData(stock)
    maturities = np.divide(maturity_values,365)

    interest_rates = calculateInterestRate(strike_values, maturities, call_matrix, put_matrix, S0)

    plotIVBSQH(0, strike_values, S0, N, L, maturities, interest_rates, q, put_matrix, stock,figure_number)
    
def plotPrices(N,L,S0,stock,figure_number):
    [maturity_values, strike_values, call_matrix, put_matrix]  = getData(stock)
    maturities = np.divide(maturity_values,365)
    interest_rates = calculateInterestRate(strike_values, maturities, call_matrix, put_matrix, S0)
    
    OptimizedSet = optimimize_diff_in_IV_mat(strike_values, S0, N, L, put_matrix, maturities, interest_rates,"p")
        
    putPrice = BSQHPriceMat3(OptimizedSet[:6], 0, strike_values, S0, N, L, maturities, interest_rates, q, "p")
    plt.figure(figure_number, (15,10))
    for i in range(len(putPrice.T)):
        plt.plot(strike_values, put_matrix.T[i], label = "market price for T={} days".format(str(maturities[i] * 365)))
        plt.scatter(strike_values, putPrice.T[i], label = "model pricefor T={} days".format(str(maturities[i] * 365)))
    
    table_data = [["Volatility", "Cluster Rate", "Experation Rate", "Baseline Intensity", "mu_y", "sigma_Y"],
                  OptimizedSet[:6]]
    
    plt.table(cellText=table_data, loc='best',bbox=[0, 1.04, 1, 0.1])
    
    save_path = 'Plots/Prices/'
    filename = os.path.splitext(stock)[0] 
    picture = filename + "prices.png"
    
    plt.xlabel('Strike Price')
    plt.ylabel('Option Price')
    plt.title('Option Price Comparison For Stock {}'.format(filename))
    plt.legend()
    plt.grid(True)
    plt.savefig(save_path + picture)
    plt.show()
    
def calculateDiffInIV(S0, stock):
    
    [maturity_values, strike_values, call_matrix, put_matrix] = getData(stock)
    maturities = np.divide(maturity_values,365)
    interest_rates = calculateInterestRate(strike_values, maturities, call_matrix, put_matrix, S0)
    
    L = 10
    Ns = [4,8,16,31,64]
    
    table_data = []
    errors = []
    for N in Ns:
        [imp_vols_market, imp_vols_opt] = calculateIVBSQH(0, strike_values, S0, N, L, maturities, interest_rates, 0, put_matrix, stock)
        error = np.abs(imp_vols_market - imp_vols_opt)
        errors.append(error)
    
    headers = ["N=" + str(N) for N in Ns]
    for i in range(len(strike_values)):
        table_data.append([strike_values[i]] + [errors[j][i] for j in range(len(errors))])
        
    print(tabulate(table_data, headers, tablefmt="grid"))
    

def maincalculation():
    N = 64
    L = 8
    
    plotStock(N, L, 4311.21, 'DataS&P500L1.csv',1)
    #plotPrices(N, L, 4311.21, 'DataS&P500L1.csv',2)
    
    #plotStock(N, L, 4311.21, 'DataS&P5001.csv',3)
    #plotPrices(N, L, 4311.21, 'DataS&P5001.csv',4)
    
    #plotStock(N, L, 4374.11, 'DataS&P5002.csv',5)
    #plotPrices(N, L, 4374.11, 'DataS&P5002.csv',6)
    
    #plotStock(N, L, 4374.11, 'DataS&P500L2.csv',7)
    #plotPrices(N, L, 4374.11, 'DataS&P500L2.csv',8)
    
    #plotStock(N, L, 141.95, 'DataJPML1.csv',9)
    #plotPrices(N, L, 141.95, 'DataJPML1.csv',10)
    
    #plotStock(N, L, 141.95, 'DataJPM2.csv',11)
    #plotPrices(N, L, 141.95, 'DataJPM2.csv',12)
    
    #plotStock(N, L, 10.55, 'DataDB2.csv',13)
    #plotPrices(N, L, 10.55, 'DataDB2.csv',14)
    
    #plotStock(N, L, 10.55, 'DataDBL1.csv',15)
    #plotPrices(N, L, 10.55, 'DataDBL1.csv',16)

maincalculation()


