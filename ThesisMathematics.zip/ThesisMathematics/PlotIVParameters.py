from QH import QHSet
from CommonFunctionsMatrix import BSQHPriceMat3
from commonFunctions import interestRate_from_pcp
from py_vollib.black_scholes.implied_volatility import implied_volatility as iv
import matplotlib.pyplot as plt
from py_lets_be_rational.exceptions import BelowIntrinsicException, AboveMaximumException
import numpy as np
import csv
from scipy import optimize
from tabulate import tabulate
import time
import os
import QH

def calculateInterestRate(vecK, vecT, call_matrix, put_matrix, S0):

    interestRates = np.zeros(len(vecT))
    for j in range(len(vecT)):  
        IRperMaturity = []
        for i in range(len(vecK)):
            IRperMaturity.append(interestRate_from_pcp(call_matrix[i][j], put_matrix[i][j], S0, vecK[i],vecT[j]))
        interestRates[j] = sum(IRperMaturity)/len(vecK)
        
    return interestRates

def calcIV(prices, S0, vecK, vecT, vecr): 
    imp_vols_opt = []
    for i in range(len(vecK)):   
        #imp_vols_opt.append([])
        for j in range(len(vecT)):
            try: 
                impVol = iv(prices[i][j], S0, vecK[i], vecT[j], vecr[j], "p")
            except BelowIntrinsicException:
                impVol = 0 
            except AboveMaximumException:
                impVol = 10
            imp_vols_opt.append(impVol)
    
    return imp_vols_opt

def plotIVmertonAndBSQHClustRate():
    sigma = 0.4
    
    activationAt0 = 2 
    vecK = [100]
    vecT = [1]
    vecr = [0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "c"
    rates = [0.1,0.5,1,1.5,2,2.5]
    
    IVBSQH1 = []
    IVBSQH2 = []
    for rate in rates:
        QHSet1 = QH.QHSet("QHSet1", rate, 3, 2, 1.1, -0.3, 0.4)
        infoBSQH1 = QHSet1.getInfo()
        infoBSQH1.insert(0,sigma)
        QHSet2 = QH.QHSet("QHSet1", rate, 3, 2, 1.1, 0.3,0.4)  
        infoBSQH2 = QHSet2.getInfo()
        infoBSQH2.insert(0,sigma)
        
        pricesBSQH1 = BSQHPriceMat3(infoBSQH1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesBSQH2 = BSQHPriceMat3(infoBSQH2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        IVBSQH1.append(calcIV(pricesBSQH1, S0, vecK, vecT, vecr)[0])
        IVBSQH2.append(calcIV(pricesBSQH2, S0, vecK, vecT, vecr)[0])
        
    plt.plot(rates, IVBSQH1, label="IV BSQH Scenario A")
    plt.plot(rates, IVBSQH2, label="IV BSQH Scenario B")
    #plt.plot(rates, IVM1[i][0], label="IV Merton Scenario A")
        
    plt.xlabel('Clustering Rates')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_ClustRate.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()


def plotIVmertonAndBSQHExpRate():
    sigma = 0.4
    
    activationAt0 = 2 
    vecK = [100]
    vecT = [1]
    vecr = [0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "c"
    rates = [2.5,5,7.5,10,12.5,15,17.5,20]
    
    IVBSQH1 = []
    IVBSQH2 = []
    for rate in rates:
        QHSet1 = QH.QHSet("QHSet1", 2, rate, 2, 1.1, -0.3, 0.4)
        infoBSQH1 = QHSet1.getInfo()
        infoBSQH1.insert(0,sigma)
        QHSet2 = QH.QHSet("QHSet1", 2.9, rate, 0, 1.1, 0.3,0.4)  
        infoBSQH2 = QHSet2.getInfo()
        infoBSQH2.insert(0,sigma)
        
        pricesBSQH1 = BSQHPriceMat3(infoBSQH1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesBSQH2 = BSQHPriceMat3(infoBSQH2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        IVBSQH1.append(calcIV(pricesBSQH1, S0, vecK, vecT, vecr)[0])
        IVBSQH2.append(calcIV(pricesBSQH2, S0, vecK, vecT, vecr)[0])
        
   
    plt.plot(rates, IVBSQH1, label="IV BSQH Scenario A")
    plt.plot(rates, IVBSQH2, label="IV BSQH Scenario B")
    #plt.plot(rates, IVM1[i][0], label="IV Merton Scenario A")
        
    plt.xlabel('Expiration rates')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_ExpRate.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()

#plotIVmertonAndBSQHExpRate()

def plotIVmertonAndBSQHQ0():
    sigma = 0.4
    
    activationAt0 = 2 
    vecK = [100]
    vecT = [1]
    vecr = [0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "c"
    rates = [0,1,2,3,4,5]
    
    QHSet1 = QH.QHSet("QHSet1", 2, 3, 2, 1.1, -0.3, 0.4)
    infoBSQH1 = QHSet1.getInfo()
    infoBSQH1.insert(0,sigma)
    QHSet2 = QH.QHSet("QHSet1", 2.9, 3, 0, 1.1, 0.3,0.4)  
    infoBSQH2 = QHSet2.getInfo()
    infoBSQH2.insert(0,sigma)
    MSet1 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, -0.3, 0.4)
    infoM1 = MSet1.getInfo()
    infoM1.insert(0,sigma)
    MSet2 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, 0.3, 0.4)
    infoM2 = MSet2.getInfo()
    infoM2.insert(0,sigma)
    
    IVM2 = []
    IVM1 = []
    IVBSQH1 = []
    IVBSQH2 = []
    for rate in rates:
        pricesBSQH1 = BSQHPriceMat3(infoBSQH1, rate, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesBSQH2 = BSQHPriceMat3(infoBSQH2, rate, vecK, S0, N, L, vecT, vecr, q, flag)
        IVBSQH1.append(calcIV(pricesBSQH1, S0, vecK, vecT, vecr)[0])
        IVBSQH2.append(calcIV(pricesBSQH2, S0, vecK, vecT, vecr)[0])
        pricesM1 = BSQHPriceMat3(infoM1, rate, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesM2 = BSQHPriceMat3(infoM2, rate, vecK, S0, N, L, vecT, vecr, q, flag)
        IVM1.append(calcIV(pricesM1, S0, vecK, vecT, vecr)[0])
        IVM2.append(calcIV(pricesM2, S0, vecK, vecT, vecr)[0])
        
    plt.plot(rates, IVBSQH1, label="IV BSQH Scenario A")
    plt.plot(rates, IVBSQH2, label="IV BSQH Scenario B")
    #plt.plot(rates, IVM1, label="IV Merton Scenario A")
    #plt.plot(rates, IVM2, label="IV Merton Scenario B")
    #plt.plot(rates, IVM1[i][0], label="IV Merton Scenario A")
        
    plt.xlabel('Initial value Q0')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IVQ0.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()
    
#plotIVmertonAndBSQHQ0()

def plotIVmertonAndBSQHJumpExp():
    sigma = 0.4
    
    activationAt0 = 2 
    vecK = [100]
    vecT = [1]
    vecr = [0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "c"
    rates = [-0.3,-0.2,-0.1,0,0.1,0.2,0.3]
    
    IVBSQH1 = []
    IVBSQH2 = []
    IVM = []
    for rate in rates:
        QHSet1 = QH.QHSet("QHSet1", 2, 3, 2, 1.1, rate, 0.4)
        infoBSQH1 = QHSet1.getInfo()
        infoBSQH1.insert(0,sigma)
        QHSet2 = QH.QHSet("QHSet2", 2.9, 3, 0, 1.1, rate ,0.4)  
        infoBSQH2 = QHSet2.getInfo()
        infoBSQH2.insert(0,sigma)
        MSet1 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, rate, 0.4)
        infoM1 = MSet1.getInfo()
        infoM1.insert(0,sigma)
        
        pricesBSQH1 = BSQHPriceMat3(infoBSQH1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesBSQH2 = BSQHPriceMat3(infoBSQH2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesM1 = BSQHPriceMat3(infoM1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        IVBSQH1.append(calcIV(pricesBSQH1, S0, vecK, vecT, vecr)[0])
        IVBSQH2.append(calcIV(pricesBSQH2, S0, vecK, vecT, vecr)[0])
        IVM.append(calcIV(pricesM1, S0, vecK, vecT, vecr)[0])
        
   
    plt.plot(rates, IVBSQH1, label="IV BSQH Scenario A")
    plt.plot(rates, IVBSQH2, label="IV BSQH Scenario B")
    plt.plot(rates, IVM, label="IV Merton")
    #plt.plot(rates, IVM1[i][0], label="IV Merton Scenario A")
        
    plt.xlabel('Expected Jump Size')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_ExpJS.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()

#plotIVmertonAndBSQHQ0()

def plotIVmertonAndBSQHJumpSigma():
    sigma = 0.4
    
    activationAt0 = 2 
    vecK = [100]
    vecT = [1]
    vecr = [0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "c"
    rates = [0.1,0.2,0.3,0.4,0.5]
    
    IVBSQH1 = []
    IVBSQH2 = []
    IVM1 = []
    IVM2 = []
    for rate in rates:
        QHSet1 = QH.QHSet("QHSet1", 2, 3, 2, 1.1, -0.3, rate)
        infoBSQH1 = QHSet1.getInfo()
        infoBSQH1.insert(0,sigma)
        QHSet2 = QH.QHSet("QHSet2", 2.9, 3, 0, 1.1, 0.3 ,rate)  
        infoBSQH2 = QHSet2.getInfo()
        infoBSQH2.insert(0,sigma)
        MSet1 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, -0.3, rate)
        infoM1 = MSet1.getInfo()
        infoM1.insert(0,sigma)
        MSet2 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, 0.3, rate)
        infoM2 = MSet2.getInfo()
        infoM2.insert(0,sigma)
        
        pricesBSQH1 = BSQHPriceMat3(infoBSQH1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesBSQH2 = BSQHPriceMat3(infoBSQH2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesM1 = BSQHPriceMat3(infoM1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesM2 = BSQHPriceMat3(infoM2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        IVBSQH1.append(calcIV(pricesBSQH1, S0, vecK, vecT, vecr)[0])
        IVBSQH2.append(calcIV(pricesBSQH2, S0, vecK, vecT, vecr)[0])
        IVM1.append(calcIV(pricesM1, S0, vecK, vecT, vecr)[0])
        IVM2.append(calcIV(pricesM2, S0, vecK, vecT, vecr)[0])
        
   
    plt.plot(rates, IVBSQH1, label="IV BSQH Scenario A")
    plt.plot(rates, IVBSQH2, label="IV BSQH Scenario B")
    plt.plot(rates, IVM1, label="IV Merton Scenario A")
    plt.plot(rates, IVM2, label="IV Merton Scenario B")
    #plt.plot(rates, IVM1[i][0], label="IV Merton Scenario A")
        
    plt.xlabel('Standard deviation of the Jump Size')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_SigmaJ.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()
    
plotIVmertonAndBSQHJumpSigma()
    
def plotIVmertonAndBSQHLambda():
    sigma = 0.4
    
    activationAt0 = 2 
    vecK = [100]
    vecT = [1]
    vecr = [0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "c"
    rates = [0.1,0.5,1,1.5,2,2.5]
    
    IVBSQH1 = []
    IVBSQH2 = []
    for rate in rates:
        QHSet1 = QH.QHSet("QHSet1", 2, 3, 2, 1.1, -0.3, 0.4)
        infoBSQH1 = QHSet1.getInfo()
        infoBSQH1.insert(0,sigma)
        QHSet2 = QH.QHSet("QHSet1", 2.9, 3, 2, 1.1, 0.3,0.4)  
        infoBSQH2 = QHSet2.getInfo()
        infoBSQH2.insert(0,sigma)
        
        pricesBSQH1 = BSQHPriceMat3(infoBSQH1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        pricesBSQH2 = BSQHPriceMat3(infoBSQH2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
        IVBSQH1.append(calcIV(pricesBSQH1, S0, vecK, vecT, vecr)[0])
        IVBSQH2.append(calcIV(pricesBSQH2, S0, vecK, vecT, vecr)[0])
        
    plt.plot(rates, IVBSQH1, label="IV BSQH Scenario A")
    plt.plot(rates, IVBSQH2, label="IV BSQH Scenario B")
    #plt.plot(rates, IVM1[i][0], label="IV Merton Scenario A")
        
    plt.xlabel('Clustering Rates')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_ClustRate.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()
