import numpy as np
from QH import QHSet

def integrationRange(L, T):
    a = -L * np.sqrt(T)
    b = L * np.sqrt(T)
    return [a, b]

"cosine series coefficients on an integration interval [c,d] in [a,b]"
"6.32"
def cos_ser_coef_exp(k, a, b, c, d):
    
    scalar = 1 / (1 + np.power((k * np.pi/(b-a)), 2))
    cos_part = np.cos(k*np.pi*(d-a)/(b-a)) * np.exp(d) - np.cos(k*np.pi*(c-a)/(b-a))*np.exp(c)
    sin_scalar = k*np.pi/(b-a)
    sin_part = np.sin(k*np.pi*(d-a)/(b-a)) * np.exp(d) - np.sin(k*np.pi*(c-a)/(b-a))*np.exp(c)
    
    return scalar * (cos_part + sin_scalar*sin_part)

"6.33"
def cos_ser_coef_one(k, a, b, c, d):
    if(k == 0):
        return (d-c)
    else:
        scalar = (b-a)/(k*np.pi)
      
        return scalar * (np.sin(k*np.pi * (d-a)/(b-a)) - np.sin(k*np.pi * (c-a)/(b-a)))


def scalar_U(k, a, b, flag):
    if(flag == "c"):
        return 2/(b-a)*(cos_ser_coef_exp(k, a, b, 0, b)- cos_ser_coef_one(k, a, b, 0, b))
    else:
        return 2/(b-a)*(-cos_ser_coef_exp(k, a, b, a, 0) + cos_ser_coef_one(k, a, b, a, 0))

def payoffCoef(contract, k, a, b, K):
    if (contract == "call"):
        if (a< b and b< 0.0):
            return 0.0
        else:
            return 2.0/(b-a) * K * (cos_ser_coef_exp(k, a, b, 0.0,b) - cos_ser_coef_one(k,a, b, 0.0,b))
            
    else : #if its put
        return 2.0/(b-a) * K * (-cos_ser_coef_exp(k,a,b,a,0.0) + cos_ser_coef_one(k,a,b,a,0.0))

"COS pricing formula"
def COSMethodWithScalar(t0, K, N, L, T, S0, r, cf):
    [a, b] = integrationRange(L, T)
    x = np.log(S0 / K)
    tau = T - t0
    z = 0.5 * cf(0, T)*scalar_U(0, a, b)*np.exp(0)

    for k in range(1, N):
        z += cf(k*np.pi/(b-a), T)*scalar_U(k, a, b) * \
            np.exp(1j * k * np.pi * (x-a) / (b-a))
    
    return K*np.exp(-r*tau) * z.real

"COS pricing formula"
def CosMethodWithPayOff(t0, K, N, L, T, S0, r, cf, contract):
    [a, b] = integrationRange(L, T)
    x = np.log(S0 / K)
    tau = T - t0
    z = 0.5 * (cf(0.0,T)*np.exp(0.0)).real * payoffCoef(contract,0.0, a, b, K)
    
    for k in range (1,N):
        #print("cf ",  cf(k*np.pi/(b-a), T))
        z += (cf(k*np.pi/(b-a), T) * np.exp(1j *k * np.pi * (x-a) / (b-a))).real * payoffCoef(contract,k, a, b, K)
  
    return np.exp(-r*tau) * z

"6.15"
def fourier_coef(k, a, b, cf,):
    
    c_part = cf(k*np.pi / (b-a), 0.0)
    exp_part = np.exp (-1j * (k * a * np.pi) / (b-a))
    z = c_part * exp_part
    
    return 2.0/(b-a) * z.real

"Standard normal density function, 6.17"
def fourier_pdf(y,N, L, T, cf):
    [a, b] = integrationRange(L, T)
    result = 0.5 * fourier_coef(0.0, a, b, cf) * np.cos(0.0)
    for k in range (1,N):
        result += fourier_coef(k, a, b, cf) * np.cos(k*np.pi*(y-a)/(b-a))
    return result

"put-call-parity"
def call_from_pcp(put,spot,K,r,T):
    B = np.exp(-r*T)
    return put + spot - K*B

def interestRate_from_pcp(call,put,spot,K,T):
    B = (call-put-spot)/-K
    return -np.log(B)/T

def chf_GBM(sigma, u, t, r, q):
    mu = r - 0.5*sigma**2 - q 
    return np.exp(1j*u*mu*t - 0.5*sigma**2 *u**2 * t)

def BSQHPrice(info, activationAt0, K, S0, N, L, T, r, q, flag):
    [volatility, clustRate, expRate, baseInt, mu_Y, sigma_Y] = info
        
    Set = QHSet("Set", clustRate, expRate, activationAt0, baseInt, mu_Y, sigma_Y)
    cf_BSQH = lambda u,t: chf_GBM(volatility, u, t, r, q) * QHSet.chf(Set, u ,t)
    
    BSQHPut = CosMethodWithPayOff(0, K, N, L, T, S0, r, cf_BSQH, "p")
    
    if flag == 'p':
        return BSQHPut
    else:
        return call_from_pcp(BSQHPut, S0, K, r, T)    
