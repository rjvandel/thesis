import numpy as np
from QH import QHSet
from merton import MertonSet
from commonFunctions import BSQHPrice
from commonFunctions import scalar_U, chf_GBM

"FOR MATRICES:"
"K rows, T columns"

def call_from_pcp_Mat(put,spot,K,r,T):
    B = np.exp(-r*T)
    return put + spot - np.outer(K,B)

def integrationRangeVec(L, vecT):
    ranges = []
    for T in vecT:
        a = -L * np.sqrt(T)
        b = L * np.sqrt(T)
        ranges.append([a,b]) 
    return ranges

def COSMethodWithScalarMat(t0, vecK, N, L, vecT, S0, r, cf, flag):
    "Gives for every K in vecK the option Price"
    ranges = integrationRangeVec(L, vecT)
    vecx = np.log( np.divide(S0, vecK))
    tau = vecT - t0

    z_vector = []

    for i in range(len(vecT)):
        [a,b] = ranges[i]
        z = (0.5 * cf(0, vecT[i])*scalar_U(0, a, b, flag)*np.exp(0)).real
             
        for k in range(1, N):
            z += (cf(k*np.pi/(b-a), vecT[i])*scalar_U(k, a, b, flag) * np.exp(1j * k * np.pi * (vecx-a) / (b-a))).real
        
        z_vector.append(z)
        
    return  np.outer(vecK, np.exp(-r*tau)) * np.transpose(np.array(z_vector))

def BSQHPriceMat(info, activationAt0, vecK, S0, N, L, vecT, r, q, flag):
    "Gives a list of BSQHprices"
    [volatility, clustRate, expRate, baseInt, mu_Y, sigma_Y] = info
    
    Set = QHSet("Set", clustRate, expRate, activationAt0, baseInt, mu_Y, sigma_Y)
    cf_BSQH = lambda u,t: chf_GBM(volatility, u, t, r, q) * QHSet.chf(Set, u ,t)
    
    BSQHPut = COSMethodWithScalarMat(0, vecK, N, L, vecT, S0, r, cf_BSQH, "p")
   
    if flag == 'p':
        return BSQHPut
    else:
        return call_from_pcp_Mat(BSQHPut, S0, vecK, r, vecT)  

def MertonPriceMat(info, activationAt0, vecK, S0, N, L, vecT, r, q, flag):
    [volatility_GBM,jumpInt, drift, volatility_merton] = info
    
    Set = MertonSet("Set", jumpInt, drift, volatility_merton)
    
    cf_Merton = lambda u, t: MertonSet.chf(Set, u, t, volatility_GBM, r, q)
    
    MertonPut = COSMethodWithScalarMat(0, vecK, N, L, vecT, S0, r, cf_Merton, "p")
    
    if flag == "p":
        return MertonPut
    else:
        return call_from_pcp_Mat(MertonPut, S0, vecK, r, vecT)

"Here r is a vector of interest rates"


def COSMethodWithScalar3(t0, vecK, N, L, vecT, S0, vecr, cf, flag):
    "Gives for every K in vecK the option Price"
    ranges = integrationRangeVec(L, vecT)
    vecx = np.log( np.divide(S0, vecK))
    tau = vecT - t0

    z_vector = []

    for i in range(len(vecT)):
        [a,b] = ranges[i]
        z = (0.5 * cf(0, vecT[i])*scalar_U(0, a, b, flag)*np.exp(0)).real
             
        for k in range(1, N):
            z += (cf(k*np.pi/(b-a), vecT[i])*scalar_U(k, a, b, flag) * np.exp(1j * k * np.pi * (vecx-a) / (b-a))).real
        
        z_vector.append(z)
        
        
    return np.outer(vecK * np.exp(-vecr*tau) , np.transpose(np.array(z_vector)))
    
def BSQHPriceMat3(info, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag):
    "Gives a list of BSQHprices"
    [volatility, clustRate, expRate, baseInt, mu_Y, sigma_Y] = info
    
    
    #Set = QHSet("Set", clustRate, expRate, activationAt0, baseInt, mu_Y, sigma_Y)
    
    BSQHPutMat = np.zeros((len(vecK), len(vecT)))
    for i in range(len(vecT)):
        r = vecr[i]
        for j in range(len(vecK)):
            BSQHPutMat[j][i] = BSQHPrice(info, activationAt0, vecK[j], S0, N, L, vecT[i], r, q, flag)
    
    return BSQHPutMat