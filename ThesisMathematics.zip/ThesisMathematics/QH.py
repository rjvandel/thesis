import numpy as np

class QHSet:
    def __init__(self, name, clustRate, expRate, activationAt0, baseInt, mu_Y, sigma_Y):
        self.name = name
        self.clustRate = clustRate
        self.expRate = expRate
        self.activationAt0 = activationAt0
        self.baseInt = baseInt
        self.mu_Y = mu_Y
        self.sigma_Y = sigma_Y
        
    def makeList(self):
        return [self.name, self.clustRate, self.expRate, self.baseInt, self.mu_Y, self.sigma_Y, self.activationAt0]

    def getInfo(self):
        return [self.clustRate, self.expRate, self.baseInt, self.mu_Y, self.sigma_Y]
    
    def chf(self, v, t):
        mu_bar_Y = np.exp(self.mu_Y+0.5*self.sigma_Y**2) -1
        
        chf_Y = np.exp(1j * v* self.mu_Y - 0.5*self.sigma_Y**2 *v**2)

        f = np.sqrt((self.expRate + self.clustRate*(1 + 1j * v * mu_bar_Y))** 2 
                    - 4 * self.clustRate * self.expRate * chf_Y) 
        
        g = self.expRate + self.clustRate*(1 + 1j*v*mu_bar_Y - 2*chf_Y)

        # Fractions of the calculation
        first = np.exp(self.baseInt*t / (2*self.clustRate) *
                       (self.expRate - self.clustRate - 1j*self.clustRate*mu_bar_Y*v - f))
   
        second = (2*f / (f + g + np.exp(-t*f)
                  * (f - g)))**(self.baseInt/self.clustRate)
    
        last = (((1-np.exp(-t*f)) * (2*self.expRate - (self.expRate + self.clustRate*(1+1j*v*mu_bar_Y))) +
                f*(1+np.exp(-t*f)))/(f + g + np.exp(-t*f)*(f - g)))**self.activationAt0
     
        return first * second * last
