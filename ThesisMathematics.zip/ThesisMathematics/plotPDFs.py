import numpy as np
import commonFunctions as func
import QH
import matplotlib.pyplot as plt

def mainCalculation():
    
    #QH.QHSet(name, clustRate, expRate, activationAt0, baseInt, mu_Y, sigma_Y)
    
    QHSet1 = QH.QHSet("QHSet1", 2, 3, 2, 1.1, -0.3, 0.4)
    QHSet2 = QH.QHSet("QHSet1", 2.9, 3, 0, 1.1, 0.3,0.4)   
    
    MSet1 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, -0.3, 0.4)
    MSet2 = QH.QHSet("MSet2", 0.1, 10, 0, 1.1, 0.3, 0.4)
    
    N = 64
    L = 20
    T1 = 7/365
    T2 = 0.5
    
    sigma = 0.4 
    r = 0.1 
    q = 0
    
    phiM = lambda u, t: MSet2.chf(u, t) * func.chf_GBM(sigma, u, t, r, q)
    phiBSQH = lambda u, t: QHSet2.chf(u, t) * func.chf_GBM(sigma, u, t, r, q)
    
    #plotPDF(phi1, N, L, T1)
    plotPDFs(phiM, phiBSQH, N, L, 1)

def plotPDF(phi,N,L,T):
    Y = np.arange(-1,1,0.001)
    
    fourier_pdf4, fourier_pdf8, fourier_pdf16, fourier_pdf32, fourier_pdf64 = [],[],[],[],[]
    for y in Y:
        
        func.fourier_pdf(y, N, L, T, phi)
        
        #fourier_pdf4.append(func.fourier_pdf(y,4,L,T,phi))
        #print("1")
        fourier_pdf8.append(func.fourier_pdf(y,8,L,T,phi))
        fourier_pdf16.append(func.fourier_pdf(y,16,L,T,phi))
        fourier_pdf32.append(func.fourier_pdf(y,32,L,T,phi))
        fourier_pdf64.append(func.fourier_pdf(y,64,L,T,phi))
        
    #plt.figure(name, figsize=(12,8))
    
    #plt.plot(Y, fourier_pdf4)
    plt.plot(Y, fourier_pdf8)
    plt.plot(Y, fourier_pdf16)
    plt.plot(Y, fourier_pdf32)
    plt.plot(Y, fourier_pdf64)
    
    plt.legend(['N = 8', 'N = 16', 'N = 32', 'N = 64'])
    
def plotPDFs(phiM, phiBSQH, N, L, T):
    Y = np.arange(-1,1,0.001)
    
    fourier_pdfMerton, fourier_pdfBSQH = [],[]
    for y in Y:

        fourier_pdfMerton.append(func.fourier_pdf(y,64,L,T,phiM))
        fourier_pdfBSQH.append(func.fourier_pdf(y,64,L,T,phiBSQH))
    
    
    plt.plot(Y, fourier_pdfMerton)
    plt.plot(Y, fourier_pdfBSQH)
    
    plt.legend(["Merton", "BSQH"])
    
mainCalculation()