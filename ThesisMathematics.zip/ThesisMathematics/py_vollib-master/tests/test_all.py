import pytest


pytest.main()
