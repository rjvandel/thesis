from QH import QHSet
from CommonFunctionsMatrix import BSQHPriceMat3
from commonFunctions import interestRate_from_pcp
from py_vollib.black_scholes.implied_volatility import implied_volatility as iv
import matplotlib.pyplot as plt
from py_lets_be_rational.exceptions import BelowIntrinsicException, AboveMaximumException
import numpy as np
import csv
from scipy import optimize
from tabulate import tabulate
import time
import os
import QH

def calculateInterestRate(vecK, vecT, call_matrix, put_matrix, S0):

    interestRates = np.zeros(len(vecT))
    for j in range(len(vecT)):  
        IRperMaturity = []
        for i in range(len(vecK)):
            IRperMaturity.append(interestRate_from_pcp(call_matrix[i][j], put_matrix[i][j], S0, vecK[i],vecT[j]))
        interestRates[j] = sum(IRperMaturity)/len(vecK)
        
    return interestRates

def calcIV(prices, S0, vecK, vecT, vecr): 
    imp_vols_opt = []
    for i in range(len(vecK)):   
        imp_vols_opt.append([])
        for j in range(len(vecT)):
            try: 
                impVol = iv(prices[i][j], S0, vecK[i], vecT[j], vecr[j], "p")
            except BelowIntrinsicException:
                impVol = 0 
            except AboveMaximumException:
                impVol = 10
            imp_vols_opt[i].append(impVol)
    
    return np.array(imp_vols_opt)

def plotIVmertonAndBSQHMaturities():
    sigma = 0.4
    
    QHSet1 = QH.QHSet("QHSet1", 2, 3, 2, 1.1, -0.3, 0.4)
    infoBSQH1 = QHSet1.getInfo()
    infoBSQH1.insert(0,sigma)
    QHSet2 = QH.QHSet("QHSet1", 2.9, 3, 0, 1.1, 0.3,0.4)  
    infoBSQH2 = QHSet2.getInfo()
    infoBSQH2.insert(0,sigma)
    
    MSet1 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, -0.3, 0.4)
    infoM1 = MSet1.getInfo()
    infoM1.insert(0,sigma)
    MSet2 = QH.QHSet("MSet2", 0.1, 10, 0, 1.1, 0.3, 0.4)
    infoM2 = MSet2.getInfo()
    infoM2.insert(0,sigma)
    
    activationAt0 = 2 
    vecK = [100]
    vecT = [0.25,0.75, 1, 1.25, 1.50]
    vecr = [0.1, 0.1, 0.1, 0.1, 0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "p"
    
    pricesBSQH1 = BSQHPriceMat3(infoBSQH1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    pricesBSQH2 = BSQHPriceMat3(infoBSQH2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    pricesM1 = BSQHPriceMat3(infoM1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    pricesM2 = BSQHPriceMat3(infoM2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    
    IVBSQH1 = calcIV(pricesBSQH1, S0, vecK, vecT, vecr)
    IVBSQH2 = calcIV(pricesBSQH2, S0, vecK, vecT, vecr)
    IVM1 = calcIV(pricesM1, S0, vecK, vecT, vecr)
    IVM2 = calcIV(pricesM2, S0, vecK, vecT, vecr)
    
    '''
    for i in range(len(IVBSQH1)):
        plt.plot(vecT, IVBSQH1[i], label="IV BSQH Scenario A")
        plt.plot(vecT, IVM1[i], label="IV Merton Scenario A")
        
    plt.xlabel('Maturities')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_MaturitiesA.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()
    '''
    
    for i in range(len(IVBSQH2)):
        plt.plot(vecT, IVBSQH2[i], label="IV BSQH Scenario B")
        plt.plot(vecT, IVM2[i], label="IV Merton Scenario B")
        
    plt.xlabel('Maturities')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_MaturitiesB.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()

 
plotIVmertonAndBSQHMaturities()

def plotIVmertonAndBSQHStrikes():
    sigma = 0.4
    
    QHSet1 = QH.QHSet("QHSet1", 2, 3, 2, 1.1, -0.3, 0.4)
    infoBSQH1 = QHSet1.getInfo()
    infoBSQH1.insert(0,sigma)
    QHSet2 = QH.QHSet("QHSet1", 2.9, 3, 0, 1.1, 0.3,0.4)  
    infoBSQH2 = QHSet2.getInfo()
    infoBSQH2.insert(0,sigma)
    
    MSet1 = QH.QHSet("MSet1", 0.1, 10, 0, 1.1, -0.3, 0.4)
    infoM1 = MSet1.getInfo()
    infoM1.insert(0,sigma)
    MSet2 = QH.QHSet("MSet2", 0.1, 10, 0, 1.1, 0.3, 0.4)
    infoM2 = MSet2.getInfo()
    infoM2.insert(0,sigma)
    
    activationAt0 = 2 
    vecK = [80,90,100,110,120]
    vecT = [1]
    vecr = [0.1]
    S0 = 100
    N = 64
    L = 10
    q = 0
    flag = "p"
    
    
    pricesBSQH1 = BSQHPriceMat3(infoBSQH1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    pricesBSQH2 = BSQHPriceMat3(infoBSQH2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    pricesM1 = BSQHPriceMat3(infoM1, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    pricesM2 = BSQHPriceMat3(infoM2, activationAt0, vecK, S0, N, L, vecT, vecr, q, flag)
    
    IVBSQH1 = calcIV(pricesBSQH1, S0, vecK, vecT, vecr)
    IVBSQH2 = calcIV(pricesBSQH2, S0, vecK, vecT, vecr)
    IVM1 = calcIV(pricesM1, S0, vecK, vecT, vecr)
    IVM2 = calcIV(pricesM2, S0, vecK, vecT, vecr)
    
    
    for i in range(len(IVBSQH1.T)):
        plt.plot(vecK, IVBSQH1.T[i], label="IV BSQH Scenario A")
        plt.plot(vecK, IVM1.T[i], label="IV Merton Scenario A")
        
    plt.xlabel('Strike Price')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_StrikesA.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()
    '''
    
    for i in range(len(IVBSQH2.T)):
        plt.plot(vecK, IVBSQH2.T[i], label="IV BSQH Scenario B")
        plt.plot(vecK, IVM2.T[i], label="IV Merton Scenario B")
        
    plt.xlabel('Strike Price')
    plt.ylabel('Implied Volatility')
    plt.title('Implied Volatility Comparison')
    
    save_path = 'Plots/IV/'
    picture = "IV_StrikesB.png"
    
    plt.legend()
    plt.grid(True)
    plt.savefig(picture)
    plt.show()
'''
 
#plotIVmertonAndBSQHStrikes()